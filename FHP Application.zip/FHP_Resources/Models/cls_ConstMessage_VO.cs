﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FHP_Resources
{
    public class cls_ConstMessage_VO
    {
        public string Message { get; set; }

    }
}
