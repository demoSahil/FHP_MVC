﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FHP_DL
{
    internal class cls_MessageDataHandlerFF_DL 
    {
        public byte GetKey(string messageKey, string tableName)
        {
            throw new NotImplementedException();
        }
        public string GetMessageDesc(byte key, string tableName)
        {
            throw new NotImplementedException();
        }
    }
}
